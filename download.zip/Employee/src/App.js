import Employee from './Employee.js'

const App = () => {
  return (
   <Employee />
  );
}

export default App;

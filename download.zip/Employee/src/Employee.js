import { Paper, Grid, TextField, FormLabel, RadioGroup, FormControlLabel, Radio, InputLabel, NativeSelect, Checkbox, FormGroup } from '@material-ui/core'
   let componentOptions = {"genderOptions":["Male","Female","Other"],"maritalStatusOptions":["Married","Unmarried","Other"],"languagesOptions":["English","Hindi","Spanish","Chinese","Other"],"ownPolicyOptions":["Yes","No"]}
   
const Employee = () => {
  
  return (
    <div>            
      

<Grid className="wrapper" variant="outlined">       
        <TextField id="custName" label="Customer First Name: " className="formlabel" required="true" variant="outlined" />
    </Grid>


<Grid className="wrapper" variant="outlined">       
        <TextField id="custLastName" label="Customer Last Name: " className="formlabel" required="true" variant="outlined" />
    </Grid>

   <Paper variant="outlined" className="wrapper">
            <Grid item xs>
                   <FormLabel className="formlabel" required="undefined">Gender:</FormLabel>
    
                <RadioGroup aria-label="gender" name="Gender:" >
                    {componentOptions.genderOptions.map((item) => (
                        <FormControlLabel value={item} control={<Radio />} label={item} /> ))}
                </RadioGroup>
            </Grid>
        </Paper>

    


<Paper variant="outlined" className="wrapper">
            <Grid item xs>
                <InputLabel htmlFor="select" className="formlabel" >Marital Status</InputLabel>
                    <NativeSelect id="select">
                    {componentOptions.maritalStatusOptions.map((item, i) => (
                        <option value={i}>{item}</option> ))}
                    </NativeSelect>
            </Grid>
        </Paper>
        

<Paper variant="outlined" className="wrapper">
            <Grid item xs>
               <FormLabel className="formlabel" required="true">Languages</FormLabel>
                       
                    <FormGroup>
                        {componentOptions.languagesOptions.map((item) => (
                            <FormControlLabel control={<Checkbox name={item} />} label={item} />
                            ))}
                    </FormGroup>
            </Grid>  
        </Paper>
    


   <Paper variant="outlined" className="wrapper">
            <Grid item xs>
                   <FormLabel className="formlabel" required="undefined">Do you own any policy with us?</FormLabel>
    
                <RadioGroup aria-label="ownPolicy" name="Do you own any policy with us?" >
                    {componentOptions.ownPolicyOptions.map((item) => (
                        <FormControlLabel value={item} control={<Radio />} label={item} /> ))}
                </RadioGroup>
            </Grid>
        </Paper>

    


    </div>
  )
}
export default Employee